﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vote
{
    class Program
    {
       
        static void Main(string[] args)
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.DarkBlue;


            Console.ForegroundColor = ConsoleColor.White;
            Program p = new Program();
            p.Show_op();
        }
        public void Show_op()
        {
            Console.Clear();

            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Enter your choice");
            Console.WriteLine("1.Vote");
            Console.WriteLine("2. Candiatate");
            Console.WriteLine("3. Admin login");
            Console.WriteLine("4. Exit");

            int abc = Convert.ToInt32(Console.ReadLine());

            switch (abc)
            {
                case 1:
                    {
                        Console.Clear();
                        Election ele = new Election();
                        ele.vot_id= ele.Show1();
                        int vote_i = ele.vot_id;
                                             ele.Showele(vote_i);
                        Console.ReadLine();
                        break;
                    }
                case 2:
                    {
                        Console.Clear();
                        Candidate1 cad = new Candidate1();
                        cad.Show2();
                        break;
                    }
                case 3:
                    {
                        Console.Clear();
                        Admin1 adcs = new Admin1();
                        adcs.Show1_admin();
                        break;
                    }


            }
        }


    }
}
