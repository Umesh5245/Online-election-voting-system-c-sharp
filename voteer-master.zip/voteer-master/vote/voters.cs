﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace vote

{
    interface inter1
    {
        int Show1();
    }
    abstract class Voters
    {
      
        public abstract void Showele(int voterid);
        
    }
  
    class Election : Voters, inter1
    { private int vote, vott;
        public int Show1()
        {
            Console.WriteLine("ENTER VOTER ID");
          //  int id = Convert.ToInt32(Console.ReadLine());
            Custom_Exception1 o = new Custom_Exception1("id cannot be Negative");
            o.id = Convert.ToInt16(Console.ReadLine());
            if (o.id < 0)
            {
                throw new Custom_Exception1("id cannot be Negative");
            }
            else
            {
                Console.WriteLine("Voter id is : " + o.id);
            }
            vott = o.id;
            return o.id;

        }
        public int vot_id
        {
            get
            {
                return vote;
            }
            set
            {
                vote=value;
            }
        }
        public override void Showele(int voterid)
        {
            try { 
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
            //Console.WriteLine("select voter_id from db_voters where id='" + voterid + "'");
            SqlCommand command = new SqlCommand("select Id from db_voters where Id='" + voterid + "'", con);
            con.Open();
            int result = command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    //     Console.WriteLine("{0}",  reader.GetString(0));
                    int ope = reader.GetInt32(0);
                    //   Console.WriteLine(ope);
                    if (ope == voterid)
                    {
                        Console.WriteLine("user verified");
                        voter_election(voterid);

                    }
                }
            }
            else
            {
                Console.WriteLine("No voter found.");
                Console.WriteLine("Reenter your votereid");
                Program p = new Program();
                p.Show_op();
            }
            reader.Close();

            con.Close();
            Console.WriteLine();
            }

            catch (Exception)
            {
                Console.WriteLine("Error");
            }
        }
        public void voter_election(int voterid)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
                //Console.WriteLine("select voter_id from db_voters where id='" + voterid + "'");
                SqlCommand command = new SqlCommand("select consistuency from db_voters where Id='" + voterid + "'", con);
                con.Open();
                int result = command.ExecuteNonQuery();
                SqlDataReader reader = command.ExecuteReader();
                String consistuency_voter_election = "";
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        consistuency_voter_election = reader.GetString(0);

                    }
                    Console.WriteLine(consistuency_voter_election);
                }
                else
                {
                    Console.WriteLine("No voter found.");
                }
                reader.Close();

                con.Close();
                Console.WriteLine();
                //till herre ok 
                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
                //Console.WriteLine("select voter_id from db_voters where id='" + voterid + "'");
                SqlCommand command1 = new SqlCommand("select count(Id) from db_election where constituency='" + consistuency_voter_election + "'", conn);
                conn.Open();
                int result1 = command1.ExecuteNonQuery();
                SqlDataReader reader1 = command1.ExecuteReader();
                int count_voter_election = 0;
                if (reader1.HasRows)
                {
                    while (reader1.Read())
                    {
                        count_voter_election = reader1.GetInt32(0);

                    }
                    Console.WriteLine(count_voter_election);

                }
                else
                {
                    Console.WriteLine("No voter found.");
                }

                reader1.Close();

                conn.Close();
                Console.WriteLine();
                Console.WriteLine(count_voter_election);
                if (count_voter_election > 0)
                {
                    cast_vote(consistuency_voter_election, voterid);
                }
                else
                {
                    Console.WriteLine("NO election in your Consistuency");
                }
            }
            catch(Exception)
            {
                Console.WriteLine("Error 1 ");
            }



        }
        public void cast_vote(String consistuency_voter_election,int voterid)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
                SqlCommand command = new SqlCommand("select * from db_candidate where consistuency='" + consistuency_voter_election + "'   AND verification='YES' ", con);
                con.Open();
                int result = command.ExecuteNonQuery();
                SqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("Enter Your Vote");
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("||    " + reader.GetInt32(0) + " || " + reader.GetString(1) + "   ||   " + reader.GetString(2) + "   ||   " + reader.GetString(3) + "   ||   " + reader.GetString(4) + "   ||   " + reader.GetString(5) + "   ||   " + reader.GetString(6) + "   ||   " +
                            reader.GetString(7) + "   ||   " + reader.GetString(8) + "   ||   " + reader.GetString(9) + "   ||   " + reader.GetString(10) + "   ||   ");
                    }
                    Console.WriteLine(consistuency_voter_election);
                }
                else
                {
                    Console.WriteLine("No voter found.");
                }
                reader.Close();

                con.Close();
                Console.WriteLine();
                int cast_id_vote = Convert.ToInt32(Console.ReadLine());
                //till here ok

                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
                //Console.WriteLine("select voter_id from db_voters where id='" + voterid + "'");
                SqlCommand command1 = new SqlCommand("select vote from db_candidate where Id=" + cast_id_vote, conn);
                conn.Open();
                int result1 = command1.ExecuteNonQuery();
                SqlDataReader reader1 = command1.ExecuteReader();
                int count_vote_cad = 0;
                if (reader1.HasRows)
                {
                    while (reader1.Read())
                    {
                        count_vote_cad = reader1.GetInt32(0);
                        count_vote_cad++;
                    }
                    Console.WriteLine(count_vote_cad);

                }
                else
                {
                    Console.WriteLine("No voter found.");
                }

                reader1.Close();

                conn.Close();

                SqlConnection conn1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
                //Console.WriteLine("select voter_id from db_voters where id='" + voterid + "'");
                SqlCommand command2 = new SqlCommand("update db_candidate set vote=" + count_vote_cad + "where Id=" + cast_id_vote, conn1);
                conn1.Open();
                int result2 = command2.ExecuteNonQuery();
                SqlDataReader reader2 = command2.ExecuteReader();
                if (reader2.HasRows)
                {
                    while (reader2.Read())
                    {
                        count_vote_cad = reader1.GetInt32(0);
                        count_vote_cad++;
                    }
                   
                }
                

                reader1.Close();

                conn1.Close();

            }

            catch (Exception)
            {
                Console.WriteLine("Error");
            }
        }
        


    }
}
