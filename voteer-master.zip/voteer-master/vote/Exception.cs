﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vote
{
    class Custom_Exception1 : ApplicationException
    {
        public int id;
        public Custom_Exception1(String s) : base(s)
        { }
    }
}
