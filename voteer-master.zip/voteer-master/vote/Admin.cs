﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace vote
{

    class Admin1 
    {

        protected string admin_pass, admin_id;

        

        public void Show1_admin()
        {

            Console.WriteLine("Enter Your Login ID");
            admin_id = Console.ReadLine();
            Console.WriteLine("Enter Your Password");
            admin_pass = Console.ReadLine();
            login_admin();

        }
        public void Show_admin_cases()
        {

            Console.WriteLine("Choose below option");

            Console.WriteLine("1. Add Voter");
            Console.WriteLine("2. verify candidate");
            Console.WriteLine("3. Add election");
            Console.WriteLine("4. show  result");
            Console.WriteLine("5. Exit");
            
            
            int abc = Convert.ToInt32(Console.ReadLine());
            switch (abc)
            {
                case 1:

                    enter_user();
                    break;

                case 2:
                    verify_admin_candidate();
                    break;

                case 3:
                    add_election();
                    break;
                case 4:
                     
                   addmin_show_res rest = new addmin_show_res();
                    rest.show_result();
                    break;
                case 5:
                    Program p = new Program();
                    p.Show_op();
                    break;
            }
        }
       
        public void verify_admin_candidate()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
            SqlCommand command = new SqlCommand("select * from db_candidate where verification='NO'", con);
            con.Open();
            int result = command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();


            if (reader.HasRows)
            {
                while (reader.Read())
                {



                    Console.WriteLine("ID:  " + reader.GetInt32(0));

                    Console.WriteLine("First name:       " + reader.GetString(1));
                    Console.WriteLine("Last name:         " + reader.GetString(2));
                    Console.WriteLine("Gender:            " + reader.GetString(3));
                    Console.WriteLine("Consistuency:      " + reader.GetString(4));
                    Console.WriteLine("Age  :             " + reader.GetString(5));
                    Console.WriteLine("Income :           " + reader.GetString(6));
                    Console.WriteLine("Croiminal Cases:   " + reader.GetString(7));
                    Console.WriteLine("verification  :    " + reader.GetString(8));
                    Console.WriteLine("Policital Party:   " + reader.GetString(9));
                    Console.WriteLine("Date of Birth : " + reader.GetString(10));
                    string s = reader.GetDateTime(11).ToShortDateString();
                    Console.WriteLine(" Form Submitted on:   " + s);
                    Console.WriteLine();


                    Console.WriteLine("Want verify user (type'Y/ N')");
                    string verify_admin_cad = Console.ReadLine();
                    if (verify_admin_cad == "y" || verify_admin_cad == "Y" || verify_admin_cad == "yes" || verify_admin_cad == "YES" || verify_admin_cad == "Yes")
                    {
                        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
                        conn.Open();

                        SqlCommand cmd1 = new SqlCommand("update db_candidate set verification='YES' where id=@id", conn);
                        cmd1.Parameters.AddWithValue("@id", reader.GetInt32(0));
                        int i = cmd1.ExecuteNonQuery();
                        if (i != 0)
                        {
                            Console.WriteLine("update successful");
                        }
                        conn.Close();

                    }
                }
            }
            else
            {
                Console.WriteLine("No  Unverified user found.");
            }
            Console.ReadLine();
            reader.Close();

            con.Close();

        }
       
        public  void login_admin()
        {
            if (admin_id == "admin")
            {
                if (admin_pass == "admin")
                {
                    Console.WriteLine("user verified ");
                    Show_admin_cases();
                }
                else
                {
                    Console.WriteLine("wrong id ");
                    Show1_admin();
                }
            }
            else
            {
                Console.WriteLine("wrong id ");
                Show1_admin();
            }
        }
        public void enter_user_data(String name, String age, String gender, String consistuency)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("insert into db_voters (name,age,gender,consistuency) values('" + name + "','" + age + "','" + gender + "','" + consistuency + "')", conn);

                Console.WriteLine("insert into db_voters (name,age,gender,consistuency) values('" + name + "','" + age + "','" + gender + "','" + consistuency + "')");
                conn.Open();
                int i = cmd.ExecuteNonQuery();
                if (i != 0)
                {
                    Console.WriteLine("update successful");
                }
                conn.Close();
            }

            catch (Exception)
            {
                Console.WriteLine("Error");
            }
            Console.WriteLine();
        }
        public void enter_user()
        {
            Console.WriteLine("Enter Name");
            String name_enter = Console.ReadLine();
            Console.WriteLine("Enter Age Of voter");
            String age_enter = Console.ReadLine();
            Console.WriteLine("Enter Gender of Voter (M/F");
            String gender_enter = Console.ReadLine();
            if (gender_enter == "M" || gender_enter == "m")
            {
                gender_enter = "Male";
            }
            else if (gender_enter == "F" || gender_enter == "f")
            {
                gender_enter = "Female";
            }
            Console.WriteLine("enter voters Consistuency");
            String consistunecy_enter = Console.ReadLine();
            enter_user_data(name_enter, age_enter, gender_enter, consistunecy_enter);
        }

        public void add_election()
        {
            Console.WriteLine("Enter constituency");
            String constituency_admin_addelection = Console.ReadLine();
            Console.WriteLine("Enter Election Type");
            String elecType_admin_addelection = Console.ReadLine();
            Console.WriteLine("Enter Election Date");
            String date_admin_addelection = Console.ReadLine();
            add_election_data(date_admin_addelection, elecType_admin_addelection, date_admin_addelection);
        }
        public void add_election_data(String date_admin_enterelection, String electype_admin_enterelection, String constituency_admin_enterelction)

        {
            // constituency
            try { 
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into db_election (type,date,constituency) values('" + electype_admin_enterelection + "','" + date_admin_enterelection + "','" + constituency_admin_enterelction + "')", conn);

            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                Console.WriteLine("update successful");
            }
            conn.Close();
            }

            catch (Exception)
            {
                Console.WriteLine("Error");
            }

            Console.WriteLine();

        }
    }
    sealed class addmin_show_res
        {
        public void show_result()
        {
            
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
            SqlCommand command = new SqlCommand("select DISTINCT constituency from db_election", con);
            con.Open();
            int result = command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();


            while (reader.Read())
                {

                String con_admin_result = reader.GetString(0);
                Console.WriteLine(con_admin_result);


                show_result1(con_admin_result);


                }
                
            Console.ReadLine();
            reader.Close();

            con.Close();
        }
        public void show_result1(String con_admin_result)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
            conn.Open();
            Console.WriteLine(con_admin_result);
            SqlCommand cmd1 = new SqlCommand("select * from db_candidate where vote=(select Max(vote) from db_candidate where consistuency='"+con_admin_result+"')", conn);
               int i = cmd1.ExecuteNonQuery();
            SqlDataReader reader1 = cmd1.ExecuteReader();
            reader1.Read();
            if (reader1.HasRows)
            {

                
                Console.WriteLine("||    " + reader1.GetInt32(0) + " || " + reader1.GetString(1) + "   ||   " + reader1.GetString(2) + "   ||   " + reader1.GetString(3) + "   ||   " + reader1.GetString(4) + "   ||   " + reader1.GetString(5) + "   ||   " + reader1.GetString(6) + "   ||   " +
                    reader1.GetString(7) + "   ||   " + reader1.GetString(8) + "   ||   " + reader1.GetString(9) + "   ||   " + reader1.GetString(10) + "   ||   ");
                Console.WriteLine("Vote is:"+reader1.GetInt32(12));
            }
            conn.Close();

        }
    }

}
