﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace vote
{
     
    interface inter3
    {
        void Show2();
    }
    abstract class Candidate : inter3
    {
        //  protected string admin_pass, admin_id;

        //  public abstract void login_admin();

        public void Show2()
        {
            Console.WriteLine("Choose below option");

            Console.WriteLine("1. Add your name for elelction");
            Console.WriteLine("2. See Your vote Status");
            Console.WriteLine("3. Exit");
            int abc = Convert.ToInt32(Console.ReadLine());
            switch (abc)
            {
                case 1:
                    Candidate1 cad = new Candidate1();

                    cad.add_can();
                    break;

                case 2:
                    Candidate1 cad1= new Candidate1();
                    cad1.show_cad_status();

                    break;
                case 3:
                    Program p = new Program();
                    p.Show_op();
                    break;


            }
        }
    }
    class Candidate1 : Candidate
    {
       
        public void show_cad_status()
        {
            try
            {
                Console.WriteLine("Enter your Candidate id");
                int Stat_id = Convert.ToInt32(Console.ReadLine());
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
                SqlCommand command = new SqlCommand("select Id,verification from db_candidate where Id=" + Stat_id, con);
                con.Open();
                int result = command.ExecuteNonQuery();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int ope = reader.GetInt32(0);
                        if (ope == Stat_id)
                        {
                            //int ope = reader.GetInt32(0);

                            String verri = reader.GetString(1);
                            Console.WriteLine(verri);

                        }
                    }
                }
                else
                {
                    Console.WriteLine("No user found.");
                }
                reader.Close();

                con.Close();
            }
            catch (Exception)
            {
                Console.WriteLine("Error");
            }
        }
        public void add_candidate_data(String fname_enter, String lname_enter, String gender_enter, String consistunecy_enter, String age_enter, String income_enter, String case_enter,String dob,String pol_party,String date)
        {
         
                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\UMESH\DOWNLOADS\VOTEER-MASTER(4)\VOTEER-MASTER\VOTE\DATABASE2.MDF;Integrated Security=True");
                //Console.WriteLine("select voter_id from db_voters where voter_id='" + voterid + "'");
                SqlCommand cmd1 = new SqlCommand("insert into db_candidate (fname,lname,gender,consistuency,age,income,cases,verification,pol_party,cad_date,sub_date,vote) values('" + fname_enter + "','" + lname_enter + "','" + gender_enter + "','" + consistunecy_enter + "','" + age_enter + "','" + income_enter + "','" + case_enter + "','NO','" + pol_party + "','" + dob + "','" + date + "',0)", conn);
                conn.Open();
                int i = cmd1.ExecuteNonQuery();
                if (i != 0)
                {
                    Console.WriteLine("update successful");
                }
                conn.Close();
                Console.WriteLine();
                Show2();
            

        }
        public void add_can()
        { Console.WriteLine("Enter First Name");
            String fname_enter = Console.ReadLine();
            Console.WriteLine("Enter Last Name");
            String lname_enter = Console.ReadLine();
            Console.WriteLine("Enter Gender (M/F)");
            String gender_enter = Console.ReadLine();
            if (gender_enter == "M" || gender_enter == "m")
            {                gender_enter = "Male";
            }
            else if (gender_enter == "F" || gender_enter == "f")
            {
                gender_enter = "Female";
            }
            Console.WriteLine("enter Consistuency");
            String consistunecy_enter = Console.ReadLine();
            Console.WriteLine("Enter Age Of Candidate");
            String age_enter = Console.ReadLine();
            Console.WriteLine("enter Income");
            String income_enter = Console.ReadLine();
            Console.WriteLine("enter cases (if yes describe only in 120char)");
            String case_enter = Console.ReadLine();
            Console.WriteLine("enter your Date of birth" );
            String dob = Console.ReadLine();
            Console.WriteLine("Enter your policital party");
            String pol_party = Console.ReadLine();
          
            DateTime aDate = DateTime.Now;

          String now=aDate.ToString("MM/dd/yyyy");
            add_candidate_data(fname_enter,lname_enter,gender_enter,consistunecy_enter,age_enter,income_enter,case_enter,dob,pol_party,now);
        }
       


    }
}
